import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {FormControl, NgModel, Validators} from '@angular/forms';
import {FormBuilder} from '@angular/forms';
import {BreakpointObserver} from '@angular/cdk/layout';
import {StepperOrientation} from '@angular/material/stepper';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {MatChipInputEvent} from '@angular/material/chips';
import {MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { IDropdownSettings } from 'ng-multiselect-dropdown';


@Component({
  selector: 'app-cust-mat-form',
  templateUrl: './cust-mat-form.component.html',
  styleUrls: ['./cust-mat-form.component.css']
})
export class CustMatFormComponent implements OnInit {

  // constructor(private _formBuilder: FormBuilder) {}

  ngOnInit(): void {
    // this.editon = false;
    
    this.defaultvalue.disable();

    // multi select dropdown

    this.dropdownList = [
      { item_id: 1, item_text: 'Mumbai' },
      { item_id: 2, item_text: 'Bangaluru' },
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' },
      { item_id: 5, item_text: 'New Delhi' }
    ];
    this.selectedItems = [
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 6,
      allowSearchFilter: true
    };

    // multi select dropdown ends
  
  }

  mothertongue = ['English', 'Tamil', 'Urdu', 'Hindi'];

  gender: string[] = ['Male', 'Female'];

  areaofinterestlist = ['angular','react','jquery','c#','php','java']

  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  defaultsetVal = "mohan"

  // areaofinterest = this._formBuilder.group({
  //   angular: false,
  //   react: false,
  //   jquery: false,
  // })

  // validation
  name = new FormControl('', Validators.required);
  number = new FormControl('', Validators.required);
  email = new FormControl('', [Validators.required, Validators.email]);
  selectgender = new FormControl('', Validators.required);
  toppings = new FormControl('');
  // defaultvalue = new FormControl({value: 'Nancy', disabled: true}, Validators.required);
  defaultvalue = new FormControl('azeez');

  getNameErrorMessage(){
    if (this.name.hasError('required')) {
      return 'You must enter a value';
    }
  }
  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }
    return this.email.hasError('email') ? 'Not a valid email' : '';
  }
  // validation end

  // stepper start
  
  isLinear = true;

  firstFormGroup = this._formBuilder.group({
    firstCtrl: ['', Validators.required],
  });
  secondFormGroup = this._formBuilder.group({
    secondCtrl: ['', Validators.required],
  });
  thirdFormGroup = this._formBuilder.group({
    thirdCtrl: ['', Validators.required],
  });
  stepperOrientation: Observable<StepperOrientation>;

  constructor(private _formBuilder: FormBuilder, breakpointObserver: BreakpointObserver) {
    this.stepperOrientation = breakpointObserver
      .observe('(min-width: 800px)')
      .pipe(map(({matches}) => (matches ? 'horizontal' : 'vertical')));
    
    // chips
    this.filteredFruits = this.fruitCtrl.valueChanges.pipe(
      startWith(null),
      map((fruit: string | null) => (fruit ? this._filter(fruit) : this.allFruits.slice())),
    );
  }
  // stepper end

  // upload file
  @ViewChild('fileInput') fileInput: ElementRef;
  fileAttr = 'Choose File';
  uploadFileEvt(imgFile: any) {
    if (imgFile.target.files && imgFile.target.files[0]) {
      this.fileAttr = '';
      Array.from(imgFile.target.files).forEach((file: any) => {
        this.fileAttr += file.name + ' - ';
      });
      // HTML5 FileReader API
      let reader = new FileReader();
      reader.onload = (e: any) => {
        let image = new Image();
        image.src = e.target.result;
        image.onload = (rs) => {
          let imgBase64Path = e.target.result;
        };
      };
      reader.readAsDataURL(imgFile.target.files[0]);
      // Reset if duplicate image uploaded again
      this.fileInput.nativeElement.value = '';
    } else {
      this.fileAttr = 'Choose File';
    }
  }
  numinwords: any;
  // slider
  value = 0;

  editon = false;

  onEdit(){
    // this.editon = true;
    this.defaultvalue.enable();
  }

  isChecked  = true;
  
  // chips

  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new FormControl('');
  filteredFruits: Observable<string[]>;
  // fruits: string[] = ['Lemon'];
  allFruits: string[] = ['Apple', 'Lemon', 'Lime', 'Orange', 'Strawberry'];

  @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement>;

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our fruit
    if (value) {
      this.fruits.push(value);
    }

    // Clear the input value
    event.chipInput!.clear();

    this.fruitCtrl.setValue(null);
  }

  remove(fruit: string): void {
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.fruits.push(event.option.viewValue);
    this.fruitInput.nativeElement.value = '';
    this.fruitCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allFruits.filter(fruit => fruit.toLowerCase().includes(filterValue));
  }

  // accordian
  // items = ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5'];
  fruits = [];
  expandedIndex = 0;

  // multi select dropdown
  dropdownList = [];
  selectedItems = [];
  // dropdownSettings = {};
  dropdownSettings:IDropdownSettings;
  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
}
