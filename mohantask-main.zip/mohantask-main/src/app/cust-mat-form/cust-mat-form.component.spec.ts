import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustMatFormComponent } from './cust-mat-form.component';

describe('CustMatFormComponent', () => {
  let component: CustMatFormComponent;
  let fixture: ComponentFixture<CustMatFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustMatFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustMatFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
