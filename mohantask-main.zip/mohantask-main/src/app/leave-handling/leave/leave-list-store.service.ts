import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { HttpParams } from "@angular/common/http";
import { SigninService } from "../sign-in/signin.service";
import { CurrentUser } from "../sign-in/currentuser.model";
import { take } from "rxjs";
import { map } from "rxjs";
import { exhaustMap } from "rxjs";
import { tap } from "rxjs";

@Injectable({providedIn:'root'})

export class LeaveService{

    constructor( 
        private http: HttpClient, 
        private signinService: SigninService
    ){}

    leavelist = [];
    usertoken: any;
    // leave: any;

    addfirstleave(leavedata){
        // to get the token of current user
        this.signinService.currentuser.subscribe(name => {
            this.usertoken = name.id
        });

        // this.leavelist.map( currentleavedata => {
        //     currentleavedata.eid == leavedata.eid;
        //     console.log('duplicate leave data')
        // })
        
        // this.leavelist.push(leavedata);
        this.http
            .put(
                'https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/leavelist/firstleave.json?auth='+ this.usertoken, 
                leavedata
            )
            .subscribe(response => {
                console.log(response);
            })
            
        console.log(this.leavelist)
    }
    
    addleavelist(leavedata){
        // to get the token of current user
        this.signinService.currentuser.subscribe(name => {
            this.usertoken = name.id
        });

        // this.leavelist.map( currentleavedata => {
        //     currentleavedata.eid == leavedata.eid;
        //     console.log('duplicate leave data')
        // })
        
        // this.leavelist.push(leavedata);
        this.http
            .post(
                'https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/leavelist.json?auth='+ this.usertoken, 
                leavedata
            )
            .subscribe(response => {
                console.log(response);
            })
            
        console.log(this.leavelist)
    }

    updateleavelist(updateleavedata){
        this.signinService.currentuser.subscribe(name => {
            this.usertoken = name.id
        });
        this.http
            .patch(
                'https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/leavelist/'+ updateleavedata.uniqueid + '.json?auth='+ this.usertoken, 
                updateleavedata
            )
            // https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/leavelist/-N8cs8vpP1secyiTXkUP
            .subscribe(response => {
                console.log(response);
            })
    }

    getleavefromServer(){
        return this.signinService.currentuser.pipe(
            take(1),
            exhaustMap(user => {
                return this.http
                    .get(
                        'https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/leavelist.json',
                         {
                            params: new HttpParams().set('auth', user.id)
                         }   
                        )        
            }),
            map( leavelist => {
                console.log(leavelist);
                // to convert jobject in to an array
                let convertlist = [];
                for(const key in leavelist){
                    leavelist[key].uniqueid = key;
                    convertlist.push(leavelist[key]);
                    console.log(convertlist);
                }
                return convertlist;
            }),
            tap(
                leavelist => {
                    let convertlist = [];
                    for(const key in leavelist){
                        convertlist.push(leavelist[key]);
                    }   
                    // this.leavelist.push(...convertlist);
                    this.leavelist = convertlist;
                    // console.log('leavelist - ', this.leavelist);
                }
            )
            )
    }

}