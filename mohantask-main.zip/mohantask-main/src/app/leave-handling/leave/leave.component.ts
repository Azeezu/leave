import {AfterViewInit, Component, ViewChild, OnInit} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Student } from '../general-details/student.model';
import { LeaveService } from './leave-list-store.service';
import { SigninService } from '../sign-in/signin.service';
import { StudentStorageService } from '../profile/studentstore.service';

@Component({
  selector: 'app-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.css']
})
export class LeaveComponent implements OnInit {

  private leaveData = [];
  currentusermail : string;
  roleofuser : string

  constructor( 
    private leavedataservice: LeaveService,
    private signinService:SigninService,
    private studentlistservice: StudentStorageService) { }

  displayedColumns: string[] = ['S.No','eid', 'name', 'leaveType', 'leaveDate'];
  // displayedColumns: string[] ;
  dataSource: MatTableDataSource<Student>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit(): void {

    // if(this.leavedataservice.leavelist.length == 0){
    //   // fetching leave data from database
    //   this.leavedataservice.getleavefromServer().subscribe();
    // }
    
    this.leavedataservice.getleavefromServer().subscribe();
    this.leaveData = this.leavedataservice.leavelist;
    this.dataSource = new MatTableDataSource(this.leaveData);

    this.signinService.currentuser.subscribe(name => {
      this.currentusermail = name.email;
   })

   for(var i=0; i<this.studentlistservice.studentlist.length; i++){
     if(this.currentusermail == this.studentlistservice.studentlist[i].email){
        this.roleofuser = this.studentlistservice.studentlist[i].role;
      }
    }

    if(this.roleofuser == 'manager'){
      this.displayedColumns = ['S.No','eid', 'name', 'leaveType', 'leaveDate', 'Approve'];  
    }
    else{
      this.displayedColumns = ['S.No','eid', 'name', 'leaveType', 'leaveDate'];  
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onApprove(rowdata){
    
    this.leaveData.map( data=>{
      if(data.eid == rowdata.eid){
        data.approve = true;
        data.status = false;
        // this.leavedataservice.leavelist.map( dataapprove => {
        //   dataapprove.approve = true;
        //   dataapprove.status = false;
        // })
        this.leavedataservice.updateleavelist(data);
      }
    })
  }
  

}
