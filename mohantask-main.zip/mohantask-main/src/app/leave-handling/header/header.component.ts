import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { SigninService } from '../sign-in/signin.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {

  authenticate = false;
  private signinsub : Subscription;
  
  constructor( private signinService: SigninService) { }

  ngOnInit(): void {
    this.signinsub = this.signinService.currentuser.subscribe( signinuser => {
      this.authenticate = !signinuser ? false : true;
    });
  }

  ngOnDestroy(): void {
    this.signinsub.unsubscribe();
  }
}
