import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http"
import { map } from "rxjs";
import { StudentStorageService } from "../profile/studentstore.service";
import { tap } from "rxjs";
import { Student } from "./student.model";
import { BehaviorSubject } from "rxjs";
import { SigninService } from "../sign-in/signin.service";
import { exhaustMap } from "rxjs";
import { take } from "rxjs";
import { HttpParams } from "@angular/common/http";
import { CurrentUser } from "../sign-in/currentuser.model";

@Injectable({providedIn: 'root'})

export class DataHandlingService{

    constructor( 
        private http: HttpClient,
        private studentDataService: StudentStorageService,
        private signinService: SigninService){}

    currentuser =  new BehaviorSubject<CurrentUser>(null);
    token: string = null;

    fetchStudent(){
            return this.signinService.currentuser.pipe(
                take(1),
                exhaustMap(user => {
                    return this.http
                        .get<Student[]>(
                            'https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/studentlist.json',
                             {
                                params: new HttpParams().set('auth', user.id)
                             }   
                            )        
                }),
                map(
                    studentlist => {
                        return studentlist;
                    }
                ),
                tap(
                    studentlist => {
                        this.studentDataService.storeStudents(studentlist)
                    }
                ))
            // return this.http
            // .get<Student[]>('https://leave-3dbd8-default-rtdb.asia-southeast1.firebasedatabase.app/studentlist.json')
            // .pipe( 
            //     map( studentlist => {
            //         return studentlist;
            //     }),
            //     // map( studentlist => {
            //     //     return studentlist.map( studentlist => {
            //     //         return {...studentlist}
            //     //     });
            //     // }),
            //     // map(
            //     //     studentlist => {
            //     //         const studentArray = [];
            //     //         for(const key in studentlist){
            //     //             if(studentlist.hasOwnProperty(key)){
            //     //                 studentArray.push({...studentlist[key], id: key});
            //     //             }
            //     //         }
            //     //         return studentArray;
            //     //     }
            //     // ),
            //     tap(
            //         studentlist => {
            //             this.studentDataService.storeStudents(studentlist)
            //         }
            //     )
                
            // )
    }
}