export class Student {
    constructor(
      public eid: number, 
      public name: string,
      public email: string, 
      public age: number, 
      public gender: string,
      public role: string,
      public status: string,
      public approve: string
    ) {}
  }
  