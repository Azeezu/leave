import { Injectable } from "@angular/core";
import { Student } from "../general-details/student.model";
import { Subject } from "rxjs";
import { LeaveService } from "../leave/leave-list-store.service";

@Injectable({providedIn:'root'})

export class StudentStorageService{

     constructor( private leavelistservice: LeaveService){}

    studentsupdate = new Subject <Student[]>()
    
    public studentlist = [];
    // public studentlist = [
    //     {   
    //         eid: 1111,
    //         name: 'Selva', 
    //         email: 'selva@gmail.com', 
    //         gender: 'male',
    //         age: 25,
    //         role: 'manager',
    //         status: ''
    //     },
    //     {
    //         eid: 1112,
    //         name: 'Nirmal',
    //         email: 'nirmal@gmail.com',
    //         gender: 'male',
    //         age: 25,
    //         role: 'junior',
    //         status: ''
    //     }
    // ]

    storeStudents(studentdata){
        this.studentlist.push(...studentdata);
        // this.studentlist = studentdata;
        this.studentsupdate.next(this.studentlist.slice());
    }

    getstudents(){
        return this.studentlist.slice();
    }
    
    sendtoleaveService(leavedata){
        if(this.leavelistservice.leavelist.length != 0){
            this.leavelistservice.addleavelist(leavedata);
            this.leavelistservice.leavelist.map( leavelist => {
                if(leavelist.eid == leavedata.eid){
                    leavedata.status = true;
                    leavedata.approve = false;
                    this.leavelistservice.updateleavelist(leavedata);        
                }
                // else{
                //     // this.leavelistservice.addleavelist(leavedata);
                //     this.leavelistservice.leavelist.push(leavedata);
                // }
            })
            this.leavelistservice.leavelist.push(leavedata);
        }
        else{
            leavedata.uniqueid = 'firstleave';
            this.leavelistservice.addfirstleave(leavedata);
            this.leavelistservice.leavelist.push(leavedata);
        }
        // this.leavelistservice.addleavelist(leavedata);
    }

    getleavelist(){
        return this.leavelistservice.leavelist;
    }
}