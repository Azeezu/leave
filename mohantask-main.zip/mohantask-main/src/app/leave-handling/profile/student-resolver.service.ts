import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { DataHandlingService } from "../general-details/data-handling.service";
import { Student } from "../general-details/student.model";
import { StudentStorageService } from "./studentstore.service";

@Injectable({providedIn:'root'})

export class StudentResolverService implements Resolve<Student[]>{
    
    constructor( private studentdata: StudentStorageService, private studentfetchdata: DataHandlingService){}
    
    resolve( route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
        
        const studentlist = this.studentdata.getstudents();

        if(studentlist.length === 0){
            this.studentfetchdata.fetchStudent();
        }
        else{
            return studentlist;
        }

    }
}