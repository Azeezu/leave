import {AfterViewInit, Component, ViewChild, OnInit, Inject, Input} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Student } from '../general-details/student.model';
import { DataHandlingService } from '../general-details/data-handling.service';
import { StudentStorageService } from './studentstore.service';
import {MatDialog, MAT_DIALOG_DATA, MatDialogConfig, MatDialogRef} from '@angular/material/dialog';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { CurrentUser } from '../sign-in/currentuser.model';
import { SigninService } from '../sign-in/signin.service';
import { LeaveService } from '../leave/leave-list-store.service';


// dialog data
export interface DialogData {
  animal: 'panda' | 'unicorn' | 'lion';
}
// dialog data end

/**
 * @title Data table with sorting, pagination, and filtering.
 */

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements  AfterViewInit, OnInit {
  
  displayedColumns: string[] = ['S.No','eid',  'name', 'email', 'age', 'gender', 'leave'];
  dataSource: MatTableDataSource<Student>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  applyforLeave = [];
  applyforLeaveid;
  leavelist = [];
  leavestatus = false;
  currentusermail : string;
  roleofuser : string

  private studentData : Student[] = [];

  constructor( 
    private dataHandling: DataHandlingService, 
    private studentDataService: StudentStorageService, 
    public dialog: MatDialog,
    private signinService: SigninService,
    private leavelistdata: LeaveService) {}

  // dialog box open
  openDialog(row) {
    const dialogRef = this.dialog.open(DialogDataExampleDialog, {
      data: {
        row
      },
    });
    // dialog box close after save
    dialogRef.afterClosed().subscribe(data => {
      console.log('data -',data);
      if(data){
        this.studentData = this.studentDataService.studentlist;
        this.studentData.forEach(stulist => { 
          if(stulist.eid == data.row.eid){
            data.row.status = true;
          }
        })
      }
    })
  }

  // dialog box open end
  
  ngOnInit(): void {
    
    // getting local data
    this.studentData = this.studentDataService.studentlist;
    
    // to disable apply button if leavelist has same eid
    // this.leavelistdata.leavelist.map( leavedata => {
    //     console.log(leavedata)
    //   }
    // )
    this.studentData.map( studentlist => {
      // console.log('student-list -',studentlist )
      this.leavelistdata.leavelist.map(leavelist => {
            console.log('leave-list -', leavelist)
            if(studentlist.eid == leavelist.eid){
              // console.log('eid - ', leavelist.eid)
              // console.log('status - ', leavelist.status)
              studentlist.status = leavelist.status;
              studentlist.approve = leavelist.approve;
              // console.log('status - ', studentlist.status)
            }
          })
    })

    // fetching data from database
    // this.dataHandling.fetchStudent()
    // .subscribe(studentlist => {
    //   this.studentData = studentlist;
    // });

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(this.studentData);
    

    this.signinService.currentuser.subscribe(name => {
       this.currentusermail = name.email;
    })

    for(var i=0; i<this.studentData.length; i++){
      if(this.currentusermail == this.studentData[i].email){
        this.roleofuser = this.studentData[i].role;
      }
    }

    if(this.roleofuser == 'manager'){
      this.displayedColumns = ['S.No','eid',  'name', 'age', 'gender'];  
    }
    else{
      this.displayedColumns = ['S.No','eid',  'name', 'age', 'gender', 'leave'];  
    }

    
  }
  
  

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  
}

// *************  Component for dialog box/popup *****************
@Component({
  selector: 'dialog-data-example-dialog',
  templateUrl: 'dialog-data-example-dialog.html',
})
export class DialogDataExampleDialog implements OnInit{

  datafromatable;

  rowData = [];

  leavetype: string[] = ['Personal Leave', 'Sick Leave','Avail Comp Off', 'Paternity Leave'];

  leavestatus = false;

  

  employeeForm : FormGroup;

  leaveDate = new FormControl('');

  leaveType = new FormControl('');

  selectleaveDate;

  selectleaveType;
  matDialogReference: any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private studentDataService: StudentStorageService,
    private dialogRef: MatDialogRef<DialogDataExampleDialog>) {}

  ngOnInit(): void {
    console.log(this.data);
    this.employeeForm = new FormGroup({
      'leaveDate' : new FormControl(''),
      'leaveType' : new FormControl('')
    });
    this.datafromatable = {...this.data};
  }

  onSubmit(){
    this.leavestatus = true;
    this.selectleaveDate = this.employeeForm.value.leaveDate;
    this.selectleaveType = this.employeeForm.value.leaveType;
    this.datafromatable.row.leaveDate = this.selectleaveDate;
    this.datafromatable.row.leaveType = this.selectleaveType;
    this.datafromatable.row.status = this.leavestatus;
    // sending status to store in leavelist
    this.studentDataService.sendtoleaveService(this.datafromatable.row);
    this.dialogRef.close(this.datafromatable);
  }

}