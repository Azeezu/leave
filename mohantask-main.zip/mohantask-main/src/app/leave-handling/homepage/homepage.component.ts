import { Component, OnInit } from '@angular/core';
import { SigninService } from '../sign-in/signin.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(
    private signinService: SigninService
  ) { }

  currentusermail ;
  
  ngOnInit(): void {
    this.signinService.currentuser.subscribe(name => {
      this.currentusermail = name.email;
   })

  }

}
