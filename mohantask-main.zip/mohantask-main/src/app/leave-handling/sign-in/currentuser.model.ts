export class CurrentUser{
    constructor(
        public email: string,
        public id : string,
        private  _idToken : string,
        private _tokenExpiryDate : Date,
    ){}

    get idToken(){
        if(!this._tokenExpiryDate || new Date > this._tokenExpiryDate){
            return null;
        }
        return this._idToken;
    }
}