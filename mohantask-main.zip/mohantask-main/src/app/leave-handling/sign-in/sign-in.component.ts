import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SigninService } from './signin.service';
import { DataHandlingService } from '../general-details/data-handling.service';
import { LeaveService } from '../leave/leave-list-store.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  constructor( 
    private signinservice: SigninService, 
    private router: Router,
    private dataHandling: DataHandlingService,
    private leavelist: LeaveService) { }

  signupmode = false;
  signinForm : FormGroup;
  pwd = new FormControl('', Validators.required)
  email = new FormControl('', [Validators.required, Validators.email]);

  ngOnInit(): void {
    this.signinForm = new FormGroup({
      'pwd': new FormControl('', Validators.required),
      'email' : new FormControl('', [Validators.required, Validators.email])
    });
  }

  getPwdErrorMessage(){
    if (this.pwd.hasError('required')) {
      return 'You must enter a value';
    }
  }
  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }
    return this.email.hasError('email') ? 'Not a valid email' : '';
  }

  SwitchMode(){
    this.signupmode = !this.signupmode;
  }

  onSubmit(){  
    const email = this.signinForm.value.email; 
    const pwd = this.signinForm.value.pwd;
    if(this.signupmode){
      this.signinservice.signup(email, pwd).subscribe(
        signupData => {
          this.signupmode = true;
          console.log(signupData);

          // fetching data from database
          this.dataHandling.fetchStudent().subscribe();
          // fetching leave data from database
          this.leavelist.getleavefromServer().subscribe();

          this.router.navigate(['./leave-handling/profile']);
        },
        error => {
          console.log(error);
        }
      )  
    }
    else{
      this.signinservice.login(email, pwd).subscribe(
        signupData => {
          this.signupmode = true;
          console.log(signupData);

          // fetching data from database
          this.dataHandling.fetchStudent().subscribe();
          // fetching leave data from database
          this.leavelist.getleavefromServer().subscribe();

          // this.router.navigate(['./leave-handling/profile']);
          this.router.navigate(['./leave-handling/homepage']);
          // this.router.navigate(['./leave-handling/leave']);
          
        },
        error => {
          console.log(error);
        }
      )
    }
    
  }
  

}
