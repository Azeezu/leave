import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { BehaviorSubject, tap } from "rxjs";
import { CurrentUser } from "./currentuser.model";

interface signinresponse{
    kind: string;
    idToken	: string;
    email :	string;
    refreshToken : string;
    expiresIn : string;
    localId : string;
    registered? : boolean;
}

@Injectable({providedIn: 'root'})

export class SigninService{

    constructor(private http: HttpClient){}

    currentuser = new BehaviorSubject<CurrentUser>(null);
    
    signup(email: string, pwd: string){
        return this.http.post<signinresponse>(
            'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyD3m48l17qBdS-cjeZW-TjAs6FpjKo1XeM',
            {
                email: email,
                password: pwd,
                returnSecureToken: true
            }
        ).pipe(
            tap( resData => {
                this.storeAuthentication(
                    resData.email,
                    resData.idToken,
                    resData.localId,
                    resData.expiresIn
                );
            })
        );  
    }

    login(email: string, pwd: string){
        return this.http.post<signinresponse>(
            'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyD3m48l17qBdS-cjeZW-TjAs6FpjKo1XeM',
            {
                email: email,
                password: pwd,
                returnSecureToken: true
            }
        ).pipe(
            tap( resData => {
                this.storeAuthentication(
                    resData.email,
                    resData.idToken,
                    resData.localId,
                    resData.expiresIn
                );
            })
        ); 
    }

    private storeAuthentication(
        email,
        id,
        tokenId,
        expiresIn
    ){
        const newUser =  new CurrentUser(
            email,
            id,
            tokenId,
            expiresIn
        );
        this.currentuser.next(newUser);
    }
}