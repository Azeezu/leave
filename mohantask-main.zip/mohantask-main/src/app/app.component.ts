import { Component, OnInit} from '@angular/core';
import { UntypedFormArray, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  
  title = 'mohantask';
  studentForm: UntypedFormGroup;
  gender = ['male', 'female']
  // areaofinterest = ['angular','react','jquery','c#','php','java']
  areaofinterest = [
    {name: 'angular', value: 'angular'},
    {name: 'react', value: 'react'},
    {name: 'jquery', value: 'jquery'},
    {name: 'php', value: 'php'}
  ];
  mothertongue = ['English', 'Tamil', 'Urdu', 'Hindi'];
  duplicatecontrol ;

  constructor(){}

  
  ngOnInit(){
    this.studentForm = new UntypedFormGroup({
      'userdata': new UntypedFormGroup({
        'name': new UntypedFormControl(null, Validators.required),
        'email': new UntypedFormControl(null, [Validators.required, Validators.pattern(`^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$`)]),  
      }),
      // 'name': new FormControl(null, Validators.required),
      // 'email': new FormControl(null, [Validators.required, Validators.email]),
      'date': new UntypedFormControl(null, Validators.required), 
      // 'selectinterest': new FormGroup({
      //   'areaofinterest': new FormControl([]),
      // }),
      'areaofinterest': new UntypedFormArray([], Validators.required),
      'gender': new UntypedFormControl('male', Validators.required),
      'mothertongue': new UntypedFormControl(null, Validators.required),
      'dateRange': new UntypedFormGroup({
        'fromDate': new UntypedFormControl(null, Validators.required),
        'toDate': new UntypedFormControl(null, Validators.required),  
      }),
    })
  }
  
  getControl(){
    return (<UntypedFormArray>this.studentForm.get('areaofinterest')).controls;
  }

  onselected(event: any){
    const control = new UntypedFormControl(event, Validators.required);
    this.duplicatecontrol = this.studentForm.get('areaofinterest');
    //checked
    if(event.target.checked) {
      // firstcheckbox
      if(this.duplicatecontrol.value.length == 0){
        (<UntypedFormArray>this.studentForm.get('areaofinterest')).push(control);
      }
      //selecting 2nd checkbox
      else if(this.duplicatecontrol.value.length > 0){
        for(let i=0; i<=this.duplicatecontrol.length ; i++){
          if(event.target.value == this.duplicatecontrol.value[i].target.value){
            break;
          }
          else{
            (<UntypedFormArray>this.studentForm.get('areaofinterest')).push(control);
            break;
          }
        }  
      }
    }
    //notchecked
    else{
      for(let i=0; i<=this.duplicatecontrol.length ; i++){
        if(event.target.value == this.duplicatecontrol.value[i].target.value){
          this.duplicatecontrol.controls.splice(i, 1);
          this.duplicatecontrol.value.splice(i, 1);
          break;
        }
      }
    }
  }  
  // onselected(event: any){
  //   if(event.target.checked){
  //     const control = new FormControl(event, Validators.required);
  //     this.duplicatecontrol = this.studentForm.get('areaofinterest');    
  //     for(let i=0; i<=this.duplicatecontrol.length ; i++){
  //       if(this.duplicatecontrol.value.length > 0){
  //         if(event.target.value == this.duplicatecontrol.value[i].target.value){
  //           break;
  //         }
  //         else{
  //           (<FormArray>this.studentForm.get('areaofinterest')).push(control);
  //           break;
  //         }
  //       }
  //       else{
  //         (<FormArray>this.studentForm.get('areaofinterest')).push(control);
  //         break;
  //       }
  //     }
  //   }
  //   else{
  //     // duplicatecontrol.value[0].target.value
  //     this.duplicatecontrol = this.studentForm.get('areaofinterest');    
  //     for(let i=0; i<=this.duplicatecontrol.value.length ; i++){
  //       if(event.target.value == this.duplicatecontrol.value[i].target.value){
  //         this.duplicatecontrol.controls.splice(i, 1);
  //         this.duplicatecontrol.value.splice(i, 1);
  //         break;
  //       }
  //     }
  //   }
    // console.log(this.studentForm);    
  // }

  
  onSubmit(){
    debugger
    console.log(this.studentForm.value)
    const name = this.studentForm.get('userdata.name').value;
    const email = this.studentForm.get('userdata.email').value;
    const date = this.studentForm.get('date').value;
    const mothertongue = this.studentForm.get('mothertongue').value;
    const gender = this.studentForm.get('gender').value;
    const interest = this.studentForm.get('areaofinterest').value;
    let selectedinterest = [];
    for(let i=0; i<interest.length ; i++){
      selectedinterest.push(interest[i].target.value);
    }
    console.log('name: ' + name);
    console.log('email: ' + email);
    console.log('Date of Birth: ' + date);
    console.log('Gender: ' + gender);
    console.log('Mother Tongut: ' + mothertongue);
    console.log('Area of Interest: ' + selectedinterest);
  }

  todate =  true;
  fromDate(event){
    // empty to date
    this.studentForm.get('dateRange.toDate').reset();
  }
  
}

// @Component({
//   selector: 'dialog-data-example-dialog',
//   templateUrl: 'dialog-data-example-dialog.html',
// })
// export class DialogDataExampleDialog implements OnInit{

//   studentdata ;
//   details;

//   constructor(
//     private studentlistService: StudentStorageService, 
//     private dialogRef: MatDialogRef<DialogDataExampleDialog>,
//     @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

//   ngOnInit(): void {
//     const dialogConfig = new MatDialogConfig();
//     dialogConfig.data = this.studentlistService.studentlist;
//     console.log(dialogConfig.data[0]);
//     this.details = dialogConfig.data[0].name;
//     // this.studentdata = this.studentlistService.studentlist;
//   }

// }

