import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import { AngMatFormComponent } from './ang-mat-form/ang-mat-form.component';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { CustMatFormComponent } from './cust-mat-form/cust-mat-form.component';
// cust-mat-form
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import {MatIconModule} from '@angular/material/icon';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatStepperModule} from '@angular/material/stepper';
// drag and drop
import { FilePickerModule } from  'ngx-awesome-uploader';
import { MatToolbarModule} from '@angular/material/toolbar';
import { NgxNumToWordsModule } from 'ngx-num-to-words'; 
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatChipsModule} from '@angular/material/chips';   
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import {CdkAccordionModule} from '@angular/cdk/accordion';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxFileDragDropModule  } from 'ngx-file-drag-drop';
import { SignInComponent } from './leave-handling/sign-in/sign-in.component';
import { ProfileComponent } from './leave-handling/profile/profile.component';
import { LeaveComponent } from './leave-handling/leave/leave.component';
import { HeaderComponent } from './leave-handling/header/header.component';
// leave application
import { RoutingModule } from './routing/routing.module';//name of module which we create
import { RouterModule } from '@angular/router';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { HttpClientModule } from '@angular/common/http';
import {MatDialogModule} from '@angular/material/dialog';
import { DialogDataExampleDialog } from './leave-handling/profile/profile.component';
import { HomepageComponent } from './leave-handling/homepage/homepage.component';
// import { StudentResolverService } from './leave-handling/profile/student-resolver.service';


@NgModule({
  declarations: [
    AppComponent,
    AngMatFormComponent,
    CustMatFormComponent,
    SignInComponent,
    ProfileComponent,
    LeaveComponent,
    HeaderComponent,
    DialogDataExampleDialog,
    HomepageComponent
  ],

  imports: [
    BrowserModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatSliderModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatCardModule,
    // cust-mat-form
    MatFormFieldModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatIconModule,
    MatRadioModule,
    MatCheckboxModule,
    MatStepperModule,
    FormsModule,
    MatToolbarModule,
    FilePickerModule,
    NgxNumToWordsModule,
    MatSlideToggleModule,
    MatChipsModule,
    MatAutocompleteModule,
    CdkAccordionModule,
    NgxFileDragDropModule ,
    NgMultiSelectDropDownModule.forRoot(),
    // leave application
    RouterModule,
    RoutingModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    HttpClientModule,
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
