import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from '../leave-handling/profile/profile.component';
import { LeaveComponent } from '../leave-handling/leave/leave.component';
import { SignInComponent } from '../leave-handling/sign-in/sign-in.component';
import { HomepageComponent } from '../leave-handling/homepage/homepage.component';
// import { StudentResolverService } from '../leave-handling/profile/student-resolver.service';

const mainRoutes : Routes = [
  {
    path:'',
    redirectTo:'sign-in/authentication',
    pathMatch: 'full'
  },
  {
    path: 'leave-handling/homepage',
    component: HomepageComponent,
  },
  {
    path: 'leave-handling/profile',
    component: ProfileComponent,
    // resolve: [StudentResolverService]
  },
  {
    path: 'leave-handling/leave',
    component: LeaveComponent
  },
  {
    path: 'sign-in/authentication',
    component: SignInComponent
  }

]

@NgModule({
  imports: [
    RouterModule.forRoot(mainRoutes),
    CommonModule
  ],
  exports: [RouterModule]
})
export class RoutingModule { }
